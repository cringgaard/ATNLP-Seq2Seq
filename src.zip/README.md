# ATNLP-Seq2Seq
A repo for our course project in the Advanced Topics in Natural Language Processing at UCPH

# Running the code
## Requirements
To run the code first install pytorch and the other requirements
## Fetch dataset
Then run scan_dataset.py to create the dataset
## Running the experiments
Then you can run:
* experiment_1.py
* experiment_2.py
* experiment_3_jump.py
* experiment_3_turn_left.py

